import React from 'react';
function Navbar(){
    return (
        <div>

    <nav className="navbar">
    <div class="topnav">
 Navbar
</div> 
    </nav>
        </div>

    )
}

 

export default Navbar;