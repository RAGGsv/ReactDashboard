import React from 'react';
function Mantenimiento(){
    return (
        <div class="content">
                <h1>Mantenimiento</h1>
   
        </div>

    )
}

 

export default Mantenimiento;