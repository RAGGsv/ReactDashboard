import React from 'react';
function Dashboard(){
    return (
        <div class="content">
                    <h1>Dashboard</h1>
              <card class="card"> Contenido</card>      
        </div>

    )
}

 

export default Dashboard;