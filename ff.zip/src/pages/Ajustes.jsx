import React from 'react';
function Ajustes(){
    return (
        <div class="content">
                <h1>Ajustes</h1>
   
        </div>

    )
}

 

export default Ajustes;