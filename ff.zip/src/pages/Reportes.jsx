import React from 'react';
function Reportes(){
    return (
        <div class="content">
                <h1>Reportes</h1>
   
        </div>

    )
}

 

export default Reportes;